% generated after experiments by summarize_icassp2027.py
